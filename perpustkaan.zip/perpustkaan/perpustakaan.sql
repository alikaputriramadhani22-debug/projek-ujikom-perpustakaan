-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Apr 2026 pada 04.25
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `crud_anggota`
--

CREATE TABLE `crud_anggota` (
  `id` int(25) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `no_anggota` int(25) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `kelas` int(25) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `crud_anggota`
--

INSERT INTO `crud_anggota` (`id`, `nama`, `no_anggota`, `jenis_kelamin`, `kelas`, `status`) VALUES
(1, 'icaa', 12345, 'perempuan', 12, 'aktif'),
(20, 'Luri', 22, 'perempuan', 12, 'aktif'),
(113, 'Alikaa', 2, 'P', 12, 'aktif'),
(114, 'Cacaa', 3, 'P', 11, 'aktif'),
(115, 'Alika', 2, 'P', 12, 'aktif'),
(116, 'icaa', 12345, 'P', 12, 'aktif'),
(117, 'Cacaa', 4, 'P', 12, 'aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_admin`
--

CREATE TABLE `tabel_admin` (
  `id_admin` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `role` varchar(30) DEFAULT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_admin`
--

INSERT INTO `tabel_admin` (`id_admin`, `username`, `role`, `password`) VALUES
(12, 'icaa', 'customer', '12345'),
(220, 'alika22', 'admin', '12345678');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_data_buku`
--

CREATE TABLE `tabel_data_buku` (
  `judul` varchar(25) NOT NULL,
  `id` int(25) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL,
  `jumlah_buku` int(25) NOT NULL,
  `pengarang` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_data_buku`
--

INSERT INTO `tabel_data_buku` (`judul`, `id`, `status`, `jumlah_buku`, `pengarang`) VALUES
('hewan', 1, 'aktif', 10, 'alika'),
('Casual Football', 2, 'aktif', 1, 'Alif Ibrahim Movc'),
('bahagia', 3, 'aktif', 3, 'Luri'),
('Kancil', 4, 'aktif', 55, 'Ridwan'),
('kesuksesan', 5, 'aktif', 10, 'putria'),
('pemograman', 141, 'aktif', 9, 'abyan'),
('tunggu aku sukses', 142, 'aktif', 3, 'dr.setiawan'),
('harian cool', 143, 'aktif', 10, 'jae');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_transaksi`
--

CREATE TABLE `tabel_transaksi` (
  `id` int(11) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `id_customer` varchar(25) NOT NULL,
  `judul_buku` varchar(25) NOT NULL,
  `tanggal_peminjaman` date NOT NULL,
  `tanggal_pengembalian` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_transaksi`
--

INSERT INTO `tabel_transaksi` (`id`, `Status`, `id_customer`, `judul_buku`, `tanggal_peminjaman`, `tanggal_pengembalian`) VALUES
(7, 'Disetujui', 'icaa', 'pemograman', '2026-02-22', '2026-02-22'),
(8, 'Disetujui', 'icaa', 'just tired', '2026-02-22', '2026-02-22'),
(10, 'Disetujui', 'icaa', 'Kancil', '2026-02-22', '2026-02-22'),
(11, 'Disetujui', 'icaa', 'kesuksesan', '2026-02-22', NULL),
(13, 'Disetujui', 'icaa', 'kesuksesan', '2026-03-11', NULL),
(14, 'Disetujui', 'icaa', 'kesuksesan', '2026-03-31', '2026-03-31'),
(16, 'Disetujui', 'icaa', 'tunggu aku sukses', '2026-03-31', NULL),
(18, 'Disetujui', 'icaa', 'Casual Football', '2026-04-01', NULL),
(19, 'Disetujui', 'icaa', 'tunggu aku sukses', '2026-04-01', NULL),
(20, 'Disetujui', 'icaa', 'tunggu aku sukses', '2026-04-01', NULL),
(21, 'Disetujui', 'icaa', 'tunggu aku sukses', '2026-04-01', NULL),
(22, 'Selesai', 'icaa', 'tunggu aku sukses', '2026-04-01', '2026-04-01'),
(23, 'Selesai', 'icaa', 'tunggu aku sukses', '2026-04-01', '2026-04-01'),
(24, 'Selesai', 'icaa', 'tunggu aku sukses', '2026-04-01', '2026-04-01'),
(26, 'Selesai', 'icaa', 'tunggu aku sukses', '2026-04-01', '2026-04-01'),
(27, 'Pending', 'icaa', 'Kancil', '2026-04-09', NULL),
(28, 'Pending', 'icaa', 'harian cool', '2026-04-10', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_user`
--

CREATE TABLE `tabel_user` (
  `id_user` int(3) NOT NULL,
  `nama_panjang` varchar(25) NOT NULL,
  `pasword` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabel_user`
--

INSERT INTO `tabel_user` (`id_user`, `nama_panjang`, `pasword`) VALUES
(22, 'icaa', 12345);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `crud_anggota`
--
ALTER TABLE `crud_anggota`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tabel_admin`
--
ALTER TABLE `tabel_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `tabel_data_buku`
--
ALTER TABLE `tabel_data_buku`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tabel_transaksi`
--
ALTER TABLE `tabel_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tabel_user`
--
ALTER TABLE `tabel_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `crud_anggota`
--
ALTER TABLE `crud_anggota`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT untuk tabel `tabel_admin`
--
ALTER TABLE `tabel_admin`
  MODIFY `id_admin` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2208;

--
-- AUTO_INCREMENT untuk tabel `tabel_data_buku`
--
ALTER TABLE `tabel_data_buku`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT untuk tabel `tabel_transaksi`
--
ALTER TABLE `tabel_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `tabel_user`
--
ALTER TABLE `tabel_user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
