<?php
session_start();
include 'koneksi.php';
$pesan_alert = ""; 
$redirect = ""; 

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $query_admin = mysqli_query($conn, "SELECT * FROM tabel_admin WHERE username='$username' AND password='$password'");
    
    if (mysqli_num_rows($query_admin) > 0) {
        $data = mysqli_fetch_assoc($query_admin);
        $_SESSION['user'] = $username;
        $_SESSION['role'] = $data['role']; 

        if ($data['role'] == 'admin') {
            $redirect = "dashboard.php";
        } else {
            $redirect = "dashboardcustomer.php";
        }
        $pesan_alert = "sukses";

    } else {
       
        $query_user = mysqli_query($conn, "SELECT * FROM tabel_user WHERE nama_panjang='$username' AND pasword='$password'");
        
        if (mysqli_num_rows($query_user) > 0) {
            $data = mysqli_fetch_assoc($query_user);
            $_SESSION['user'] = $username;
            $_SESSION['role'] = 'customer';
            $pesan_alert = "sukses";
            $redirect = "dashboardcustomer.php";
        } else {
            $pesan_alert = "gagal";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | perpustakaan kita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=2000');
            background-size: cover; 
            background-position: center; 
            height: 100vh;
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.1); 
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.2); 
            padding: 40px; 
            border-radius: 25px;
            width: 90%; 
            max-width: 400px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.5); 
            color: white;
        }
        .form-control { 
            background: rgba(255, 255, 255, 0.2); 
            border: 1px solid rgba(255, 255, 255, 0.1); 
            color: white !important; 
            padding: 12px; 
            border-radius: 12px;
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.25);
            border-color: #f1c40f;
            box-shadow: none;
        }
        .form-control::placeholder { color: #eee; }
        .btn-login { 
            background: #f1c40f; 
            color: #1a1a1a; 
            font-weight: 800; 
            padding: 14px; 
            border-radius: 12px; 
            width: 100%; 
            letter-spacing: 1px;
            transition: 0.3s;
        }
        .btn-login:hover {
            background: #d4ac0d;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="login-card text-center">
    <h2 class="fw-bold mb-1">perpustakaan kita</h2>
    <p class="mb-4 opacity-75 small">Silakan masuk ke akun Anda</p>
    
    <form action="" method="POST">
        <div class="mb-3">
            <input type="text" name="username" class="form-control" placeholder="Username" required autocomplete="off">
        </div>
        <div class="mb-4">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <button type="submit" name="login" class="btn btn-login border-0">MASUK</button>
    </form>
</div>

<script>
<?php if ($pesan_alert == "sukses"): ?>
    alert("✅ Login Berhasil! Peran Anda: <?= $_SESSION['role']; ?>");
    window.location.href = "<?= $redirect; ?>";
<?php elseif ($pesan_alert == "gagal"): ?>
    alert("❌ Login Gagal! Username atau Password salah.");
<?php endif; ?>
</script>

</body>
</html>