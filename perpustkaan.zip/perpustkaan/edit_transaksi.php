<?php
include "koneksi.php";
$id = $_GET['id'];
$res = mysqli_query($koneksi, "SELECT * FROM tabel_transaksi WHERE id = '$id'");
$data = mysqli_fetch_assoc($res);

if(isset($_POST['update'])){
    $judul = mysqli_real_escape_string($koneksi, $_POST['judul_buku']);
    $anggota = mysqli_real_escape_string($koneksi, $_POST['id_customer']);

    $query = "UPDATE tabel_transaksi SET judul_buku='$judul', id_customer='$anggota' WHERE id='$id'";
    
    if(mysqli_query($koneksi, $query)){
        echo "<script>alert('Data diperbarui!'); window.location='dashboard.php?page=transaksi';</script>";
    }
}
?>

<div class="p-6 max-w-lg mx-auto bg-white rounded-[2.5rem] shadow-sm mt-10">
    <h2 class="text-xl font-black mb-6">Edit Transaksi</h2>
    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-xs font-bold text-slate-400 mb-2">JUDUL BUKU</label>
            <input type="text" name="judul_buku" value="<?= $data['judul_buku'] ?>" class="w-full p-3 bg-slate-50 border-none rounded-2xl" required>
        </div>
        <div>
            <label class="block text-xs font-bold text-slate-400 mb-2">NAMA ANGGOTA</label>
            <input type="text" name="id_customer" value="<?= $data['id_customer'] ?>" class="w-full p-3 bg-slate-50 border-none rounded-2xl" required>
        </div>
        <button type="submit" name="update" class="w-full bg-indigo-600 text-white py-3 rounded-2xl font-bold shadow-lg shadow-indigo-100">Update Data</button>
    </form>
</div>
