<?php
global $koneksi, $conn;
$db = $koneksi ?? $conn;

if (!$db) {
    if (file_exists("koneksi.php")) include "koneksi.php";
    $db = $koneksi ?? $conn;
}
$q_buku = mysqli_query($db, "SELECT COUNT(*) as total FROM buku");
$total_buku = ($q_buku) ? mysqli_fetch_assoc($q_buku)['total'] : 0;

$q_agt = mysqli_query($db, "SELECT COUNT(*) as total FROM anggota");
$total_anggota = ($q_agt) ? mysqli_fetch_assoc($q_agt)['total'] : 0;
?>

<div class="bg-white p-5 rounded-3xl shadow-sm mb-6 flex items-center gap-4 border border-gray-100">
    <div class="relative">
        <div class="w-14 h-14 bg-gradient-to-tr from-green-600 to-green-400 rounded-2xl flex items-center justify-center text-white shadow-lg">
            <i class="fas fa-user-circle text-3xl"></i>
        </div>
        <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
    </div>
    <div>
        <p class="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Administrator</p>
        <p class="font-extrabold text-slate-800 text-lg leading-tight">perpustakaankuu</p>
    </div>
</div>

<h2 class="text-slate-700 font-bold mb-4 px-1 flex items-center gap-2">
    <span class="w-1 h-5 bg-green-500 rounded-full"></span> 
    Navigasi Menu
</h2>

<div class="grid grid-cols-2 gap-4">
    
    <a href="dashboard.php?page=buku" class="bg-blue-50 p-4 rounded-3xl border border-blue-100 transition active:scale-95 flex flex-col items-center text-center">
        <div class="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center text-white shadow-md mb-3">
            <i class="fas fa-book text-xl"></i>
        </div>
        <p class="text-blue-800 font-bold text-[11px] uppercase">Data Buku</p>
        <span class="text-lg font-black text-blue-600"><?= $total_buku ?></span>
    </a>

    <a href="dashboard.php?page=anggota" class="bg-purple-50 p-4 rounded-3xl border border-purple-100 transition active:scale-95 flex flex-col items-center text-center">
        <div class="w-12 h-12 bg-purple-500 rounded-2xl flex items-center justify-center text-white shadow-md mb-3">
            <i class="fas fa-users text-xl"></i>
        </div>
        <p class="text-purple-800 font-bold text-[11px] uppercase">Anggota</p>
        <span class="text-lg font-black text-purple-600"><?= $total_anggota ?></span>
    </a>

    <a href="dashboard.php?page=transaksi" class="bg-orange-50 p-4 rounded-3xl border border-orange-100 transition active:scale-95 flex flex-col items-center text-center">
        <div class="w-12 h-12 bg-orange-400 rounded-2xl flex items-center justify-center text-white shadow-md mb-3">
            <i class="fas fa-exchange-alt text-xl"></i>
        </div>
        <p class="text-orange-800 font-bold text-[11px] uppercase">Transaksi</p>
        <span class="text-[10px] text-orange-400 font-bold mt-1">PINJAM/KEMBALI</span>
    </a>

    <a href="dashboard.php?page=laporan" class="bg-emerald-50 p-4 rounded-3xl border border-emerald-100 transition active:scale-95 flex flex-col items-center text-center">
        <div class="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-md mb-3">
            <i class="fas fa-file-pdf text-xl"></i>
        </div>
        <p class="text-emerald-800 font-bold text-[11px] uppercase">Laporan</p>
        <span class="text-[10px] text-emerald-400 font-bold mt-1">CETAK DATA</span>
    </a>

</div>

   </div>
</div>