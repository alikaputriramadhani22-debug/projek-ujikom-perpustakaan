<?php
include "koneksi.php"; 
if (!isset($koneksi)) { $koneksi = $conn; } 
if(isset($_GET['aksi']) && isset($_GET['id'])){
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    
    if($_GET['aksi'] == 'setujui'){
        // 1. Ambil judul_buku dari tabel_transaksi
        $sql_transaksi = "SELECT judul_buku FROM tabel_transaksi WHERE id = '$id'";
        $query_transaksi = mysqli_query($koneksi, $sql_transaksi);
        $data = mysqli_fetch_assoc($query_transaksi);
        
        if ($data) {
            $judul_buku_pinjam = $data['judul_buku'];

            // 2. Update Status transaksi menjadi 'Disetujui'
            mysqli_query($koneksi, "UPDATE tabel_transaksi SET Status = 'Disetujui' WHERE id = '$id'");

            // 3. Update jumlah_buku di tabel_data_buku (Kurangi 1)
            $update_stok = "UPDATE tabel_data_buku SET jumlah_buku = jumlah_buku - 1 WHERE judul = '$judul_buku_pinjam'";
            mysqli_query($koneksi, $update_stok);
            
            echo "<script>alert('Data disetujui dan stok berkurang'); window.location='dashboard.php?page=transaksi';</script>";
            exit;
        }
    }
    
    if($_GET['aksi'] == 'tolak'){
        mysqli_query($koneksi, "UPDATE tabel_transaksi SET Status = 'Ditolak' WHERE id = '$id'");
        echo "<script>window.location='dashboard.php?page=transaksi';</script>";
        exit;
    }
}

// --- LOGIKA HAPUS ---
if(isset($_GET['hapus_pinjam'])){
    $id_hapus = mysqli_real_escape_string($koneksi, $_GET['hapus_pinjam']);
    if(mysqli_query($koneksi, "DELETE FROM tabel_transaksi WHERE id = '$id_hapus'")){
        echo "<script>alert('Data berhasil dihapus!'); window.location='dashboard.php?page=transaksi';</script>";
        exit;
    }
}
?>

<div class="p-4">
    <div class="flex justify-between items-center mb-6 px-1">
        <div>
            <h2 class="text-2xl font-black text-slate-800 tracking-tight">Peminjaman</h2>
            <p class="text-[10px] text-green-600 font-bold uppercase tracking-widest">Manajemen Transaksi</p>
        </div>
        </div>

    <div class="space-y-4">
        <?php
        $query = mysqli_query($koneksi, "SELECT * FROM tabel_transaksi ORDER BY id DESC");
        if(mysqli_num_rows($query) == 0) {
            echo "<p class='text-center text-gray-400 py-10'>Belum ada data transaksi.</p>";
        }
        
        while($row = mysqli_fetch_array($query)){
            $id_data = $row['id']; 
            $judul = $row['judul_buku'];
            $status_db = $row['Status'];
            $st = strtolower(trim($status_db));
        ?>
            <div class="bg-white p-5 rounded-[2.5rem] shadow-sm border border-gray-100 flex items-center justify-between transition-all hover:border-indigo-100">
                <div class="flex items-center gap-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center <?= ($st == 'disetujui') ? 'bg-green-100 text-green-600' : (($st == 'ditolak') ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600 animate-pulse') ?>">
                        <i class="fas <?= ($st == 'disetujui') ? 'fa-check-circle' : (($st == 'ditolak') ? 'fa-times-circle' : 'fa-clock') ?>"></i>
                    </div>
                    
                    <div>
                        <h4 class="font-bold text-slate-800 text-sm leading-tight"><?= $judul ?></h4>
                        <p class="text-[10px] font-medium text-slate-400">Anggota: <span class="text-indigo-500"><?= $row['id_customer'] ?></span></p>
                        
                        <div class="mt-2 inline-block px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-tighter 
                            <?= ($st == 'disetujui') ? 'bg-green-100 text-green-600' : (($st == 'ditolak') ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600') ?>">
                            <?= $status_db ?: 'Pending' ?>
                        </div>
                    </div>
                </div>

                <div class="flex gap-2 items-center"> 
                    <?php if($st != 'disetujui' && $st != 'ditolak'): ?>
                        <a href="dashboard.php?page=transaksi&aksi=setujui&id=<?= $id_data ?>" 
                           onclick="return confirm('Setujui pinjaman ini?')"
                           class="bg-green-600 text-white px-3 py-2 rounded-xl text-[9px] font-black shadow-md hover:bg-green-700">SETUJU</a>
                        
                        <a href="dashboard.php?page=transaksi&aksi=tolak&id=<?= $id_data ?>" 
                           onclick="return confirm('Tolak pinjaman ini?')"
                           class="bg-red-500 text-white px-3 py-2 rounded-xl text-[9px] font-black shadow-md hover:bg-red-600">TOLAK</a>
                    <?php endif; ?>
                    
                    <a href="dashboard.php?page=transaksi&hapus_pinjam=<?= $id_data ?>" 
                       onclick="return confirm('Hapus data ini secara permanen?')"
                       class="w-10 h-10 bg-gray-50 text-gray-300 rounded-2xl flex items-center justify-center border border-gray-100 hover:text-red-500 hover:bg-red-50 transition-colors">
                        <i class="fas fa-trash-alt text-xs"></i>
                    </a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
