<?php
include "koneksi.php";

$nama = $_POST['nama'];
$user = $_POST['username'];
$hp   = $_POST['hp'];

$query = mysqli_query($conn, "INSERT INTO tabel_anggota (nama_anggota, username, no_hp) VALUES ('$nama', '$user', '$hp')");

if($query){
    echo "<script>alert('Data berhasil terkirim ke Admin!'); window.location='index.php';</script>";
} else {
    echo "Gagal menyimpan: " . mysqli_error($conn);
}
?>