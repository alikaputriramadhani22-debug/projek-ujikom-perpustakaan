<?php
include "koneksi.php"; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        #sidebar { transition: transform 0.3s ease-in-out; }
        .sidebar-hide { transform: translateX(100%); }
        .sidebar-show { transform: translateX(0); }
    </style>
</head>
<body class="bg-gray-50">

<header class="bg-green-600 text-white p-4 sticky top-0 z-50 flex justify-between items-center shadow-md">
    <div class="flex items-center gap-2">
        <i class="fas fa-book-reader text-xl"></i>
        <h1 class="font-bold tracking-tight uppercase">perpus</h1>
    </div>
    
    <div class="flex items-center gap-3">
        <a href="logout.php" onclick="return confirm('Yakin ingin keluar?')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1.5 rounded-xl text-[10px] font-black flex items-center gap-1 transition active:scale-90 shadow-sm">
            <i class="fas fa-sign-out-alt"></i>
            KELUAR
        </a>
        <button id="menuBtn" class="text-xl px-2 focus:outline-none"><i class="fas fa-bars"></i></button>
    </div>
</header>

<div id="sidebarOverlay" class="fixed inset-0 bg-black/50 z-[60] hidden"></div>
<div id="sidebar" class="fixed top-0 right-0 h-full w-64 bg-white z-[70] shadow-2xl sidebar-hide p-5">
    <div class="flex justify-between items-center mb-8">
        <h2 class="font-bold text-green-600 italic">Main Menu</h2>
        <button id="closeBtn" class="text-gray-500 text-2xl">&times;</button>
    </div>
    
    <ul class="space-y-4">
        <li>
            <a href="dashboard.php?page=home" class="flex items-center gap-3 text-gray-700 hover:text-green-600 font-medium">
                <i class="fas fa-home w-6"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="dashboard.php?page=buku" class="flex items-center gap-3 text-gray-700 hover:text-green-600 font-medium">
                <i class="fas fa-book w-6"></i> Data Buku
            </a>
        </li>
        <li>
            <a href="dashboard.php?page=anggota" class="flex items-center gap-3 text-gray-700 hover:text-green-600 font-medium">
                <i class="fas fa-users w-6"></i> Data Anggota
            </a>
        </li>
        <hr>
        <li>
            <a href="dashboard.php?page=transaksi" class="flex items-center gap-3 text-gray-700 hover:text-green-600 font-medium">
                <i class="fas fa-exchange-alt w-6"></i> Peminjaman
            </a>
        </li>
        <li>
            <a href="dashboard.php?page=pengembalian" class="flex items-center gap-3 text-gray-700 hover:text-green-600 font-medium">
                <i class="fas fa-undo w-6"></i> Pengembalian
            </a>
        </li>
        <li>
            <a href="dashboard.php?page=laporan" class="flex items-center gap-3 text-gray-700 hover:text-green-600 font-medium">
                <i class="fas fa-file-pdf w-6"></i> Laporan
            </a>
        </li>
    </ul>
</div>

<main class="p-4 mb-20">
    <?php 
    if(isset($_GET['page'])){
        $page = $_GET['page'];
        switch ($page) {
            case 'home': include "home.php"; break;
            case 'buku': include "halaman_buku.php"; break;
            case 'anggota': include "halaman_anggota.php"; break;
            case 'transaksi': include "halaman_transaksi.php"; break;
            case 'tambah_transaksi.php': include "tambah_transaksi.php"; break;
            case 'edit_transaksi.php': include "edit_transaksi.php"; break;
            case 'laporan': include "laporan.php"; break;
            case 'pengembalian': include "pengembalian_buku.php"; break;
          
            default:
                echo "<div class='text-center p-10 mt-10'>
                        <i class='fas fa-exclamation-triangle text-orange-400 text-4xl mb-4'></i>
                        <p class='font-bold text-slate-500'>Halaman tidak ditemukan!</p>
                      </div>";
                break;
        }
    } else {
        include "home.php";
    }
    ?>
</main>

<nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around p-2 pb-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] z-50">
    <a href="dashboard.php?page=home" class="flex flex-col items-center <?= (!isset($_GET['page']) || $_GET['page'] == 'home') ? 'text-green-600' : 'text-slate-400' ?>">
        <i class="fas fa-home text-lg"></i>
        <span class="text-[10px] mt-1 font-bold">Home</span>
    </a>
    <a href="dashboard.php?page=buku" class="flex flex-col items-center <?= (isset($_GET['page']) && $_GET['page'] == 'buku') ? 'text-green-600' : 'text-slate-400' ?>">
        <i class="fas fa-book text-lg"></i>
        <span class="text-[10px] mt-1 font-bold">Buku</span>
    </a>
    <a href="dashboard.php?page=transaksi" class="flex flex-col items-center <?= (isset($_GET['page']) && $_GET['page'] == 'transaksi') ? 'text-green-600' : 'text-slate-400' ?>">
        <i class="fas fa-exchange-alt text-lg"></i>
        <span class="text-[10px] mt-1 font-bold">Transaksi</span>
    </a>
    <a href="dashboard.php?page=laporan" class="flex flex-col items-center <?= (isset($_GET['page']) && $_GET['page'] == 'laporan') ? 'text-green-600' : 'text-slate-400' ?>">
        <i class="fas fa-file-alt text-lg"></i>
        <span class="text-[10px] mt-1 font-bold">Laporan</span>
    </a>
</nav>

<script>
    const menuBtn = document.getElementById('menuBtn');
    const closeBtn = document.getElementById('closeBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    function toggleMenu() {
        sidebar.classList.toggle('sidebar-hide');
        sidebar.classList.toggle('sidebar-show');
        overlay.classList.toggle('hidden');
    }

    menuBtn.addEventListener('click', toggleMenu);
    closeBtn.addEventListener('click', toggleMenu);
    overlay.addEventListener('click', toggleMenu);
</script>

</body>
</html>