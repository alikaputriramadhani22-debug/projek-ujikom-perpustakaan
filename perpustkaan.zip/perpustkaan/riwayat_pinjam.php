<?php
session_start();
// 1. Proteksi Halaman
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'customer') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
$user = $_SESSION['user'];

// 2. Logika Proses Pinjam
if (isset($_GET['id_buku'])) {
    $id_buku = $_GET['id_buku'];
    $tanggal_pinjam = date('Y-m-d');
    
    // Kita coba masukkan ke tabel_transaksi
    // Saya tambahkan mysqli_error supaya kalau gagal, kita tau kolom mana yang salah
    $query_pinjam = mysqli_query($conn, "INSERT INTO tabel_transaksi (username, id_buku, tgl_pinjam, status) 
                                         VALUES ('$user', '$id_buku', '$tanggal_pinjam', 'Dipinjam')");
    
    if ($query_pinjam) {
        echo "<script>alert('✅ Berhasil mengajukan peminjaman!'); window.location.href='peminjaman_buku.php';</script>";
        exit();
    } else {
        // TAMPILKAN ERROR ASLI DARI DATABASE
        $pesan_error = mysqli_error($conn);
        echo "<script>alert('❌ Gagal meminjam! Pesan Error: $pesan_error');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku | Lib-System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(rgba(0,0,0,0.8), rgba(0,0,0,0.8)), url('https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=2000');
            background-size: cover; background-attachment: fixed; color: white; min-height: 100vh;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 15px; padding: 20px;
        }
        .table { color: white; border-color: rgba(255,255,255,0.1); }
        .table thead { background: #f1c40f; color: black; }
        .btn-pinjam { background: #f1c40f; color: black; font-weight: bold; border: none; }
        .btn-pinjam:hover { background: #d4ac0d; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark py-3 mb-4 shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboardcustomer.php"><i class="bi bi-arrow-left me-2"></i> Kembali ke Dashboard</a>
        <span class="navbar-text">Halo, <strong><?= $user; ?></strong></span>
    </div>
</nav>

<div class="container">
    <div class="glass-card">
        <h2 class="mb-4 text-warning fw-bold"><i class="bi bi-journal-bookmark-fill me-2"></i> Daftar Buku Perpustakaan</h2>
        
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Buku</th>
                        <th>Kategori</th>
                        <th>Penulis</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
             <tbody>
    <?php
    // SESUAIKAN: Nama tabel di foto kamu adalah 'tabel_data_buku'
    $data_buku = mysqli_query($conn, "SELECT * FROM tabel_data_buku");

    if (!$data_buku) {
        echo "<tr><td colspan='5' class='text-center text-danger'>Error: " . mysqli_error($conn) . "</td></tr>";
    } else {
        while ($buku = mysqli_fetch_assoc($data_buku)) :
    ?>
    <tr>
        <td><?= $buku['id']; ?></td>
        
        <td class="fw-bold"><?= $buku['judul']; ?></td>
        
        <td><?= $buku['status']; ?></td>
        
        <td><?= $buku['pengarang']; ?></td>
        
        <td>
            <a href="?id_buku=<?= $buku['id']; ?>" 
               onclick="return confirm('Apakah Anda yakin ingin meminjam buku ini?')" 
               class="btn btn-sm btn-pinjam">
               <i class="bi bi-plus-circle me-1"></i> Pinjam
            </a>
        </td>
    </tr>
    <?php 
        endwhile; 
    } 
    ?>
</tbody>>
            </table>
        </div>
    </div>
</div>

</body>
</html>
</php>