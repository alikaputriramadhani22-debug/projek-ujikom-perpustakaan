<?php
include "koneksi.php"; 
if (!isset($koneksi)) { $koneksi = $conn; } 

if(isset($_GET['aksi']) && $_GET['aksi'] == 'kembalikan' && isset($_GET['id'])){
    $id_t = mysqli_real_escape_string($koneksi, $_GET['id']);
    $judul = mysqli_real_escape_string($koneksi, $_GET['judul']);
    $tgl_kembali = date('Y-m-d');
    
    // 1. Update status transaksi menjadi 'Selesai'
    $query_update = "UPDATE tabel_transaksi SET Status = 'Selesai', tanggal_pengembalian = '$tgl_kembali' WHERE id = '$id_t'";
    
    // 2. Update status buku menjadi 'aktif'
    $query_status = "UPDATE tabel_data_buku SET status = 'aktif' WHERE judul = '$judul'";

    // 3. TAMBAHAN: Update jumlah stok buku (tambah 1)
    $query_stok = "UPDATE tabel_data_buku SET jumlah_buku = jumlah_buku + 1 WHERE judul = '$judul'";

    // Jalankan semua query
    $proses1 = mysqli_query($koneksi, $query_update);
    $proses2 = mysqli_query($koneksi, $query_status);
    $proses3 = mysqli_query($koneksi, $query_stok);

    if($proses1 && $proses2 && $proses3){
        echo "<script>alert('✅ Berhasil! Buku dikembalikan dan stok bertambah.'); window.location='dashboard.php?page=pengembalian';</script>";
        exit;
    } else {
        $error = mysqli_error($koneksi);
        echo "<script>alert('❌ Gagal: $error'); window.location='dashboard.php?page=pengembalian';</script>";
        exit;
    }
}
?>


<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="min-h-screen bg-slate-50 p-4 pb-20">
    <div class="relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 rounded-[2.5rem] p-6 mb-8 shadow-xl shadow-slate-200">
        <div class="relative z-10">
            <h2 class="text-2xl font-black text-white tracking-tight flex items-center gap-3">
                <i class="fas fa-undo-alt text-yellow-400"></i>
                Pengembalian
            </h2>
            <p class="text-[11px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-1">Daftar Buku Yang Kamu Bawa</p>
        </div>
        <div class="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full"></div>
    </div>

    <div class="space-y-5">
        <?php
        // Mengambil data yang statusnya 'Disetujui' (Sedang dipinjam)
        $query = mysqli_query($koneksi, "SELECT * FROM tabel_transaksi WHERE Status = 'Disetujui' ORDER BY tanggal_peminjaman DESC");
        
        if(mysqli_num_rows($query) > 0){
            while($row = mysqli_fetch_array($query)){
                $id_data = $row['id'];
                $judul_buku = $row['judul_buku'];
        ?>
            <div class="bg-white/80 backdrop-blur-md p-1 rounded-[2.5rem] shadow-sm border border-white relative overflow-hidden group">
                <div class="p-5 flex flex-col gap-5">
                    <div class="flex items-center gap-4">
                        <div class="w-16 h-16 bg-gradient-to-tr from-indigo-500 to-purple-600 rounded-[1.8rem] flex items-center justify-center text-white shadow-lg shadow-indigo-100 rotate-3 group-hover:rotate-0 transition-transform duration-500">
                            <i class="fas fa-book-open text-2xl"></i>
                        </div>
                        
                        <div class="flex-1">
                            <h4 class="font-bold text-slate-800 text-base leading-tight"><?= $judul_buku ?></h4>
                            <div class="flex items-center gap-2 mt-1">
                                <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                                <p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Status: Sedang Dipinjam</p>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div class="bg-slate-50/50 p-3 rounded-2xl border border-slate-100">
                            <p class="text-[9px] font-bold text-slate-400 uppercase">Peminjam</p>
                            <p class="text-xs font-bold text-slate-700"><?= $row['id_customer'] ?></p>
                        </div>
                        <div class="bg-slate-50/50 p-3 rounded-2xl border border-slate-100">
                            <p class="text-[9px] font-bold text-slate-400 uppercase">Tgl Pinjam</p>
                            <p class="text-xs font-bold text-slate-700"><?= $row['tanggal_peminjaman'] ?></p>
                        </div>
                    </div>

                    <a href="dashboard.php?page=pengembalian&aksi=kembalikan&id=<?= $id_data ?>&judul=<?= urlencode($judul_buku) ?>" 
                       onclick="return confirm('Apakah buku sudah benar-benar dikembalikan?')"
                       class="w-full bg-gradient-to-r from-slate-800 to-slate-900 text-white text-center py-4 rounded-[1.8rem] text-xs font-black shadow-xl shadow-slate-200 active:scale-95 transition-all flex items-center justify-center gap-2">
                        <i class="fas fa-check-circle text-yellow-400"></i>
                        KONFIRMASI PENGEMBALIAN
                    </a>
                </div>
            </div>
        <?php 
            } 
        } else {
            echo "
            <div class='flex flex-col items-center justify-center py-20 text-center px-10'>
                <div class='w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-inner border-4 border-slate-50'>
                    <i class='fas fa-ghost text-4xl text-slate-200'></i>
                </div>
                <h3 class='text-slate-800 font-black text-lg'>Kosong Melompong</h3>
                <p class='text-[11px] text-slate-400 font-bold leading-relaxed mt-2 uppercase tracking-widest'>Semua buku sudah dikembalikan.</p>
            </div>";
        }
        ?>
    </div>
</div>