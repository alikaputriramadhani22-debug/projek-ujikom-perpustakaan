<?php
include "koneksi.php";
if (!isset($koneksi)) { $koneksi = $conn; }

$total_transaksi = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tabel_transaksi"));
$total_disetujui = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tabel_transaksi WHERE Status = 'Disetujui'"));
$total_selesai = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tabel_transaksi WHERE Status = 'Selesai'"));
?>

<div class="p-4 mb-24 bg-slate-50 min-h-screen">
    <div class="flex justify-between items-start mb-6">
        <div>
            <h2 class="text-2xl font-black text-slate-800 tracking-tight">Laporan</h2>
            <p class="text-[10px] text-indigo-600 font-bold uppercase tracking-widest">Rekapitulasi Peminjaman</p>
        </div>
    </div>

    <div class="grid grid-cols-3 gap-2 mb-6">
        <div class="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
            <p class="text-[8px] font-bold text-slate-400 uppercase mb-1">Total</p>
            <p class="text-base font-black text-slate-800"><?= $total_transaksi ?></p>
        </div>
        <div class="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
            <p class="text-[8px] font-bold text-slate-400 uppercase mb-1">Pinjam</p>
            <p class="text-base font-black text-emerald-600"><?= $total_disetujui ?></p>
        </div>
        <div class="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
            <p class="text-[8px] font-bold text-slate-400 uppercase mb-1">Selesai</p>
            <p class="text-base font-black text-blue-600"><?= $total_selesai ?></p>
        </div>
    </div>

    <div class="space-y-3">
        <?php
        $no = 1;
        $query = mysqli_query($koneksi, "SELECT * FROM tabel_transaksi ORDER BY id DESC");
        if(mysqli_num_rows($query) > 0){
            while($row = mysqli_fetch_array($query)){
                $status_raw = strtolower(trim($row['Status']));
                
                // Logika Warna & Label
                if($status_raw == 'disetujui') {
                    $bg_color = 'bg-emerald-50';
                    $text_color = 'text-emerald-600';
                } elseif($status_raw == 'selesai') {
                    $bg_color = 'bg-blue-50';
                    $text_color = 'text-blue-600';
                } else {
                    $bg_color = 'bg-slate-100';
                    $text_color = 'text-slate-500';
                }
        ?>
        <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center">
            <div class="flex flex-col gap-1 max-w-[60%]">
                <div class="flex items-center gap-2">
                    <span class="text-[10px] font-bold text-slate-300">#<?= $no++ ?></span>
                    <h3 class="text-xs font-bold text-slate-800 truncate"><?= $row['judul_buku'] ?></h3>
                </div>
                <div class="flex items-center gap-1.5">
                    <i class="far fa-user text-[10px] text-slate-400"></i>
                    <p class="text-[11px] text-slate-500"><?= $row['id_customer'] ?></p>
                </div>
                <p class="text-[9px] font-medium text-slate-400 mt-1">
                    <i class="far fa-calendar-alt mr-1"></i> <?= date('d M Y', strtotime($row['tanggal_peminjaman'])) ?>
                </p>
            </div>
            
            <div class="text-right">
                <span class="<?= $bg_color ?> <?= $text_color ?> px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider">
                    <?= $row['Status'] ?>
                </span>
            </div>
        </div>
        <?php 
            }
        } else {
            echo "<div class='bg-white p-10 rounded-2xl text-center text-xs text-slate-400 italic font-medium border border-dashed border-slate-200'>Belum ada riwayat transaksi.</div>";
        }
        ?>
    </div>
</div>

<style>
/* Memperbaiki tampilan print agar tetap berbentuk tabel */
@media print {
    body * { visibility: hidden; }
    .p-4, .p-4 * { visibility: visible; }
    .p-4 { position: absolute; left: 0; top: 0; width: 100%; padding: 0 !important; }
    button, .mb-24 { display: none !important; }
    .space-y-3 > div { 
        border: 1px solid #e2e8f0 !important; 
        break-inside: avoid; 
        margin-bottom: 10px;
    }
}
</style>
